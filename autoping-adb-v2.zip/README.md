# Auto Ping ADB untuk OpenWRT

## 📥 Instalasi
1. **Download & Extract**
```sh
wget <URL-FILE-ZIP> -O autoping-adb.zip
unzip autoping-adb.zip
cd autoping-adb
```

2. **Jalankan Install**
```sh
sh install.sh
```

## 🚀 Cara Menggunakan
Cukup jalankan:
```sh
autoping-cli
```
Lalu gunakan dashboard interaktif untuk mengontrol script.

## ❌ Troubleshooting
### 1. adb Tidak Ditemukan
Cek apakah `adb` sudah terinstall:
```sh
adb version
```
Jika belum, install dengan:
```sh
opkg update && opkg install adb
```
