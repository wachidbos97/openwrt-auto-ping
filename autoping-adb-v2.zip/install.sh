#!/bin/sh

echo "Menginstall Auto Ping ADB..."

# Pindahkan file ke lokasi yang benar
cp autoping-adb /usr/bin/autoping-adb
cp autoping-cli /usr/bin/autoping-cli

# Beri izin eksekusi
chmod +x /usr/bin/autoping-adb
chmod +x /usr/bin/autoping-cli

echo "✅ Instalasi selesai. Gunakan 'autoping-cli' untuk menjalankan dashboard."
